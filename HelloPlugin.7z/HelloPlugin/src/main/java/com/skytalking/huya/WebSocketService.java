//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.skytalking.huya;

import com.intellij.ide.util.PropertiesComponent;
import com.qq.jce.wup.UniPacket;
import com.qq.taf.jce.JceInputStream;
import com.qq.taf.jce.JceOutputStream;
import com.skytalking.bean.SocketDisconnected;
import com.skytalking.bean.SocketLoginFinished;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Request;
import okhttp3.Request.Builder;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class WebSocketService {
    private static WebSocketService ourInstance = new WebSocketService();
    private ArrayList<String> mUrls = new ArrayList<>();
    private WebSocket mWebSocket;
    private WebSocketListener mWebSocketListener = new WebSocketService.HuyaWebSocketListener();
    private Runnable mConnectRunnable = new Runnable() {
        public void run() {
            WebSocketService.this.mWebSocket = null;
            WebSocketService.this.connect();
        }
    };
    private boolean mLoginSuccessful = false;
    private Disposable mConnectDisposable;
    private int mCurrentUriIndex = 0;
    private Runnable mHeartBeatRunnable = new Runnable() {
        public void run() {
            System.out.println("heart beat");
            if (WebSocketService.this.mWebSocket != null) {
                WebSocketCommand var1 = new WebSocketCommand();
                var1.iCmdType = 5;
                JceOutputStream jceOutputStream = CommonLib.out();
                var1.writeTo(jceOutputStream);
                WebSocketService.this.mWebSocket.send(ByteString.of(jceOutputStream.toByteArray()));
                System.out.println("heart beat send");
            }
            if (mHeartBeatDisposable != null && !mHeartBeatDisposable.isDisposed()) {
                mHeartBeatDisposable.dispose();
            }
            mHeartBeatDisposable = Schedulers.io().scheduleDirect(this, 20000L, TimeUnit.MILLISECONDS);
        }
    };
    private Disposable mHeartBeatDisposable;
    private Runnable mRegisterTimeoutRunnable = new Runnable() {
        public void run() {
            WebSocketService.this.connect();
        }
    };
    private Disposable mRegisterTimeoutDisposable;


    private WebSocketService() {
    }

    private void addURL(String var1) {
        this.mUrls.add(var1);
    }

    private String getDefaultUri() {
        return "ws://ows.api.huya.com:80";
    }

    public static WebSocketService getInstance() {
        return ourInstance;
    }

    private String nextUrl() {
        if (this.mUrls.isEmpty()) {
            return this.getDefaultUri();
        } else {
            ArrayList var2 = this.mUrls;
            int var1 = this.mCurrentUriIndex++;
            String var3 = (String) var2.get(var1);
            this.mCurrentUriIndex %= this.mUrls.size();
            return var3;
        }
    }

    private void reconnect() {
        if (mConnectDisposable != null && !mConnectDisposable.isDisposed()) {
            mConnectDisposable.dispose();
        }
        mConnectDisposable = Schedulers.io().scheduleDirect(mConnectRunnable, 2000, TimeUnit.MILLISECONDS);
    }

    public void sendPacket(UniPacket uniPacket) {
        if (!mLoginSuccessful) {
            System.out.println("can not send packet due to no login");
            return;
        }
        WebSocketCommand var2 = new WebSocketCommand();
        var2.iCmdType = 3;
        var2.vData = uniPacket.encode();
        JceOutputStream var3 = new JceOutputStream();
        var2.writeTo(var3);
        this.mWebSocket.send(ByteString.of(var3.toByteArray()));
    }

    public void connect() {
        mLoginSuccessful = false;
        if (this.mWebSocket != null) {
            this.mWebSocket.close(1002, "");
        } else {
            String var1 = this.nextUrl();
            Request var2 = (new Builder()).url(var1).build();
            System.out.println("connect url:" + var1);
            this.mWebSocket = CommonLib.okHttp().newWebSocket(var2, this.mWebSocketListener);
        }
    }

    public void init() {
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Subscribe
    public void onDoLaunch(LiveLaunchRsp liveLaunchRsp) {
        if (liveLaunchRsp != null && liveLaunchRsp.vProxyList != null) {
            PropertiesComponent.getInstance().setValue("guid", liveLaunchRsp.sGuid);
            ArrayList var5 = liveLaunchRsp.vProxyList;
            for (int var2 = var5.size() - 1; var2 >= 0; --var2) {
                LiveProxyValue var4 = (LiveProxyValue) var5.get(var2);
                if (var4.eProxyType == 5 || var4.eProxyType == 7) {
                    ArrayList var6 = var4.sProxy;
                    for (int var3 = 0; var3 < var6.size(); ++var3) {
                        this.addURL("ws://" + (String) var6.get(var3));
                    }
                }
            }
        }
        this.addURL(this.getDefaultUri());
        this.connect();
    }

    public void register(long var1, long var3) {
        if (this.mWebSocket == null) {
            this.connect();
        } else {
            WebSocketCommand var5 = new WebSocketCommand();
            var5.iCmdType = 1;
            String uid = PropertiesComponent.getInstance().getValue("uid");
            WSUserInfo var6 = new WSUserInfo();
            var6.bAnonymous = false;
            var6.lUid = Long.parseLong(uid);
            var6.lTid = 77259038;
            var6.lSid = 2622305892L;
            JceOutputStream var7 = CommonLib.out();
            var6.writeTo(var7);
            var5.vData = var7.toByteArray();
            JceOutputStream var8 = CommonLib.out();
            var5.writeTo(var8);
            this.mWebSocket.send(ByteString.of(var8.toByteArray()));
            if (mRegisterTimeoutDisposable != null && !mRegisterTimeoutDisposable.isDisposed()) {
                mRegisterTimeoutDisposable.dispose();
            }
            mRegisterTimeoutDisposable = Schedulers.io().scheduleDirect(mRegisterTimeoutRunnable, 10000L, TimeUnit.MILLISECONDS);
        }
    }

    public void unregister() {
        if (mRegisterTimeoutDisposable != null && !mRegisterTimeoutDisposable.isDisposed()) {
            mRegisterTimeoutDisposable.dispose();
        }
        if (this.mWebSocket != null) {
            WebSocketCommand var1 = new WebSocketCommand();
            var1.iCmdType = 8;
            WSDeRegisterReq var2 = new WSDeRegisterReq();
            var2.iDeRegisterType = 2;
            JceOutputStream var3 = CommonLib.out();
            var2.writeTo(var3);
            var1.vData = var3.toByteArray();
            JceOutputStream var4 = CommonLib.out();
            var1.writeTo(var4);
            this.mWebSocket.send(ByteString.of(var4.toByteArray()));
        }
    }

    private class HuyaWebSocketListener extends WebSocketListener {


        private HuyaWebSocketListener() {
        }

        public void onClosed(WebSocket var1, int var2, String var3) {
            System.out.println("websocket closed : " + var3);
            WebSocketService.this.reconnect();
        }

        public void onClosing(WebSocket var1, int var2, String var3) {
            System.out.println("websocket closing : " + var3);
            if (mHeartBeatDisposable != null && !mHeartBeatDisposable.isDisposed()) {
                mHeartBeatDisposable.dispose();
            }
        }

        public void onFailure(WebSocket var1, Throwable var2, Response var3) {
            System.out.println("websocket failure : " + var2.toString());
            if (mHeartBeatDisposable != null && !mHeartBeatDisposable.isDisposed()) {
                mHeartBeatDisposable.dispose();
            }
            WebSocketService.this.reconnect();
        }

        public void onMessage(WebSocket var1, String var2) {
            System.out.println("ssss;" + var2);
        }

        /**
         * HUYA.EWebSocketCommandType = {
         * EWSCmd_NULL: 0,
         * EWSCmd_RegisterReq: 1,
         * EWSCmd_RegisterRsp: 2,
         * EWSCmd_WupReq: 3,
         * EWSCmd_WupRsp: 4,
         * EWSCmdC2S_HeartBeat: 5,
         * EWSCmdS2C_HeartBeatAck: 6,
         * EWSCmdS2C_MsgPushReq: 7,
         * EWSCmdC2S_DeregisterReq: 8,
         * EWSCmdS2C_DeRegisterRsp: 9,
         * EWSCmdC2S_VerifyCookieReq: 10,
         * EWSCmdS2C_VerifyCookieRsp: 11,
         * EWSCmdC2S_VerifyHuyaTokenReq: 12,
         * EWSCmdS2C_VerifyHuyaTokenRsp: 13,
         * EWSCmdC2S_UNVerifyReq: 14,
         * EWSCmdS2C_UNVerifyRsp: 15,
         * EWSCmdC2S_RegisterGroupReq: 16,
         * EWSCmdS2C_RegisterGroupRsp: 17,
         * EWSCmdC2S_UnRegisterGroupReq: 18,
         * EWSCmdS2C_UnRegisterGroupRsp: 19,
         * EWSCmdC2S_HeartBeatReq: 20,
         * EWSCmdS2C_HeartBeatRsp: 21,
         * EWSCmdS2C_MsgPushReq_V2: 22,
         * EWSCmdC2S_UpdateUserExpsReq: 23,
         * EWSCmdS2C_UpdateUserExpsRsp: 24,
         * EWSCmdC2S_WSHistoryMsgReq: 25,
         * EWSCmdS2C_WSHistoryMsgRsp: 26,
         * EWSCmdS2C_EnterP2P: 27,
         * EWSCmdS2C_EnterP2PAck: 28,
         * EWSCmdS2C_ExitP2P: 29,
         * EWSCmdS2C_ExitP2PAck: 30
         * };
         *
         * @param var1
         * @param var2
         */
        public void onMessage(WebSocket var1, ByteString var2) {
//            System.out.println("websocket received data : " + var2.toString());
            WebSocketCommand var3 = new WebSocketCommand();
            JceInputStream jceInputStream = CommonLib.in(var2.toByteArray());
            var3.readFrom(jceInputStream);
//            System.out.println("web command type:" + var3.iCmdType);
            switch (var3.iCmdType) {
                case 2://EWSCmd_RegisterRsp
                    if (mRegisterTimeoutDisposable != null && !mRegisterTimeoutDisposable.isDisposed()) {
                        mRegisterTimeoutDisposable.dispose();
                    }
                    WSRegisterRsp var11 = new WSRegisterRsp();
                    var11.readFrom(new JceInputStream(var3.vData));
                    System.out.println("register result : " + var11.iResCode + " " + var11.sMessage);
                    if (var11.iResCode != 0) {
                        WebSocketService.this.reconnect();
                        return;
                    }
                    loginWithCookies();
                case 3://EWSCmd_WupReq
                case 5://EWSCmdC2S_HeartBeat
                case 6://EWSCmdS2C_HeartBeatAck
                case 8://EWSCmdC2S_DeregisterReq
                default:
                    break;
                case 4://EWSCmd_WupRsp
                    UniPacket uniPacket = new UniPacket();
                    uniPacket.setEncodeName("UTF-8");
                    uniPacket.decode(var3.vData);
                    String funcName = uniPacket.getFuncName();
                    if ("sendMessage".equals(funcName)) {
                        SendMessageRsp sendMessageRsp = uniPacket.getByClass("tRsp", new SendMessageRsp());
                        System.out.println(CommonLib.display(sendMessageRsp));
                        EventBus.getDefault().post(sendMessageRsp);
                    } else if ("muteRoomUser".equals(funcName)) {
                        MuteRoomUserRsp muteRoomUserRsp = uniPacket.getByClass("tRsp", new MuteRoomUserRsp());
                        EventBus.getDefault().post(muteRoomUserRsp);
                    } else if ("getRMessageList".equals(funcName)) {
                        GetRMessageListRsp rMessageListRsp = uniPacket.getByClass("tRsp", new GetRMessageListRsp());
                        EventBus.getDefault().post(rMessageListRsp);
                    }
                    break;
                case 7:
                    WSPushMessage pushMessage = new WSPushMessage();
                    jceInputStream = CommonLib.in(var3.vData);
                    pushMessage.readFrom(jceInputStream);
                    long iUri = pushMessage.iUri;
//                    System.out.println("push message uri:" + iUri);
                    jceInputStream = CommonLib.in(pushMessage.sMsg);
                    if (pushMessage.iUri == 1400L) {
                        MessageNotice messageNotice = new MessageNotice();
                        messageNotice.readFrom(jceInputStream);
                        if (messageNotice.iShowMode != 0 && messageNotice.iShowMode != 2) {
                            break;
                        }
                        EventBus.getDefault().post(messageNotice);
                    } else if (pushMessage.iUri == 8001L) {
                        EndLiveNotice endLiveNotice = new EndLiveNotice();
                        endLiveNotice.readFrom(jceInputStream);
                        EventBus.getDefault().post(endLiveNotice);
                    } else if (pushMessage.iUri == 8000L) {
                        BeginLiveNotice beginLiveNotice = new BeginLiveNotice();
                        beginLiveNotice.readFrom(jceInputStream);
                        EventBus.getDefault().post(beginLiveNotice);
                    } else if (pushMessage.iUri == 8006L) {
                        AttendeeCountNotice attendeeCountNotice = new AttendeeCountNotice();
                        attendeeCountNotice.readFrom(jceInputStream);
                        EventBus.getDefault().post(attendeeCountNotice);
                    } else if (pushMessage.iUri == 10041L) {
                        AuditorRoleChangeNotice auditorRoleChangeNotice = new AuditorRoleChangeNotice();
                        auditorRoleChangeNotice.readFrom(jceInputStream);
                        EventBus.getDefault().post(auditorRoleChangeNotice);
                    }
                    break;
                case 9:
                    WSDeRegisterRsp wsDeRegisterRsp = new WSDeRegisterRsp();
                    wsDeRegisterRsp.readFrom(new JceInputStream(var3.vData));
                    System.out.println("resister rsp:" + CommonLib.display(wsDeRegisterRsp));
                    return;
                case 11: {//EWSCmdS2C_VerifyCookieRsp
                    JceInputStream in = CommonLib.in(var3.vData);
                    WSVerifyCookieRsp wsVerifyCookieRsp = new WSVerifyCookieRsp();
                    wsVerifyCookieRsp.readFrom(in);
                    mLoginSuccessful = wsVerifyCookieRsp.iValidate == 0;
                    if (!mLoginSuccessful) {
                        PropertiesComponent.getInstance().setValue("biztoken", null);
                    }
                    EventBus.getDefault().post(new SocketLoginFinished(mLoginSuccessful));
                }
            }
        }

        public void onOpen(WebSocket var1, Response var2) {
            System.out.println("websocket opened");
            if (mConnectDisposable != null && !mConnectDisposable.isDisposed()) {
                mConnectDisposable.dispose();
            }
            if (mHeartBeatDisposable != null && !mHeartBeatDisposable.isDisposed()) {
                mHeartBeatDisposable.dispose();
            }
            mHeartBeatDisposable = Schedulers.io().scheduleDirect(mHeartBeatRunnable, 20000L, TimeUnit.MILLISECONDS);
            EventBus.getDefault().post(new SocketDisconnected());
            register(0, 0);
        }
    }

    private void loginWithCookies() {
        WSVerifyCookieReq wsVerifyCookieReq = new WSVerifyCookieReq();
        String uid = PropertiesComponent.getInstance().getValue("uid");
        String biztoken = PropertiesComponent.getInstance().getValue("biztoken");
        if (uid == null || biztoken == null) {
            System.out.println("uid =" + uid + ",biztoken=" + biztoken);
            return;
        }
        System.out.println("正在通过cookie登录");
        wsVerifyCookieReq.sGuid = PropertiesComponent.getInstance().getValue("guid");
        wsVerifyCookieReq.sCookie = "udb_uid=" + uid + "; udb_biztoken=" + biztoken;
        wsVerifyCookieReq.sUA = "XiaoHuYaWebSocket";
        wsVerifyCookieReq.lUid = Long.parseLong(uid);
        wsVerifyCookieReq.bAutoRegisterUid = 1;
        JceOutputStream out = CommonLib.out();
        wsVerifyCookieReq.writeTo(out);
        WebSocketCommand webSocketCommand = new WebSocketCommand();
        webSocketCommand.iCmdType = 10;//EWSCmdC2S_VerifyCookieReq: 10,
        webSocketCommand.vData = out.toByteArray();
        JceOutputStream out1 = CommonLib.out();
        webSocketCommand.writeTo(out1);
        mWebSocket.send(ByteString.of(out1.toByteArray()));
    }

    public boolean isLoginSuccessful() {
        return mLoginSuccessful;
    }
}
