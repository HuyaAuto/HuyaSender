//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.skytalking.huya;

public class ResGetTicket {
    String token;
    int tokenType;
    long uid;

    public ResGetTicket() {
    }

    public String getToken() {
        return this.token;
    }

    public int getTokenType() {
        return this.tokenType;
    }

    public long getUid() {
        return this.uid;
    }

    public void setToken(String var1) {
        this.token = var1;
    }

    public void setTokenType(int var1) {
        this.tokenType = var1;
    }

    public void setUid(long var1) {
        this.uid = var1;
    }
}
