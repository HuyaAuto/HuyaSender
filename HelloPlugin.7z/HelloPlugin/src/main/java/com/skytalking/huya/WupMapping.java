package com.skytalking.huya;

public class WupMapping {


}
