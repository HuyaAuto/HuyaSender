package com.skytalking.huya;

public interface TemplateType {
    int PRIMARY = 1;
    int RECEPTION = 2;
}
