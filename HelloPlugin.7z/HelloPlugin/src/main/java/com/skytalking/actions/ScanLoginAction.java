package com.skytalking.actions;

import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.skytalking.popup.ScanCodeDialogWrapper;
import icons.PluginIcons;
import org.jetbrains.annotations.NotNull;

public class ScanLoginAction extends AnAction {

    public ScanLoginAction() {
        getTemplatePresentation().setText("扫码登录");
        getTemplatePresentation().setIcon(PluginIcons.SCAN);

    }

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        new ScanCodeDialogWrapper().showAndGet();
    }
}
