package com.skytalking.plugin

import com.intellij.openapi.application.Application
import com.intellij.openapi.components.ApplicationComponent

class MyPlugin implements ApplicationComponent {
}
