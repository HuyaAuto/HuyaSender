package com.skytalking.bean;

public class BarrageBean {
}
