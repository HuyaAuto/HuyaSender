package com.skytalking.model;

import com.skytalking.bean.BarrageBean;

import javax.swing.*;

public class BarrageListModel extends DefaultListModel<BarrageBean> {
}
