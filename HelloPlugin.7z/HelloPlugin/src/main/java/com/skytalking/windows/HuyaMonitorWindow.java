package com.skytalking.windows;

import com.intellij.openapi.actionSystem.ActionManager;
import com.intellij.openapi.actionSystem.ActionToolbar;
import com.intellij.openapi.actionSystem.DefaultActionGroup;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.ui.components.JBLabel;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import com.intellij.ui.content.ContentManager;
import com.qq.taf.jce.JceStruct;
import com.skytalking.actions.ScanLoginAction;
import com.skytalking.actions.StartMonitorAction;
import com.skytalking.bean.SocketLoginFinished;
import com.skytalking.huya.*;
import com.skytalking.services.HuyaMonitorService;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HuyaMonitorWindow {
    private final Project project;
    final StartMonitorAction startMonitor;
    final ScanLoginAction scanLogin;
    private JPanel content;
    private JList<JceStruct> barrage_list;
    private JTextField text_input;
    private JButton text_send;
    private JScrollPane barrage_scroller;
    private final DefaultListModel<JceStruct> defaultListModel;
    private boolean mScrollerLocked = false;
    private int maxCount = 200;
    private ActionToolbar actionToolbar;
    private PreviewComponent windowPanel;
    private JceStruct mSelectedMessage;

    public HuyaMonitorWindow(Project project) {
        this.project = project;
        this.startMonitor = new StartMonitorAction();
        scanLogin = new ScanLoginAction();
        scanLogin.getTemplatePresentation().setEnabled(false);
        defaultListModel = new DefaultListModel<>();
        text_send.addActionListener(this::sendMessage);
        barrage_list.setModel(defaultListModel);
        barrage_list.setComponentPopupMenu(createPopupMenu());
        barrage_list.addMouseListener(mouseAdapter);
        barrage_list.setCellRenderer(listCellRenderer);
        initEventBus();
    }

    public void sendMessage(ActionEvent actionEvent) {
        WupService.getInstance().sendMessage(77259038, 2622305892L, 927093742, text_input.getText());
    }

    public void muteRoomUser() {
        MuteRoomUserReq muteRoomUserReq = new MuteRoomUserReq();
    }

    private MouseAdapter mouseAdapter = new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON3) {
                int location = barrage_list.locationToIndex(e.getPoint());
                mSelectedMessage = defaultListModel.getElementAt(location);
                barrage_list.getComponentPopupMenu().show(e.getComponent(), e.getX(), e.getY());
            }
        }
    };

    private ListCellRenderer<JceStruct> listCellRenderer = (jList, jceStruct, i, b, b1) -> {
        Component component = null;
        String messageContent = CommonLib.getMessageContent(jceStruct);
        if (messageContent != null) {
            component = new JBLabel(messageContent);
        }
        if (component == null) {
            component = new JBLabel("------------------------");
        }
        return component;
    };

    private JMenuItem createMenuAction(String text, int type, int duration) {
        JMenuItem jMenuItem = new JMenuItem(text);
        MuteRoomUserAction muteRoomUserAction = new MuteRoomUserAction(type, duration);
        return jMenuItem;
    }

    private class MuteRoomUserAction extends AbstractAction {
        public static final int TYPE_MUTE = 0;
        public static final int TYPE_BLOCK = 1;
        private int type;
        private int duration;

        public MuteRoomUserAction(int type, int duration) {
            this.type = type;
            this.duration = duration;
        }

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            if (mSelectedMessage instanceof MessageNotice) {
                MessageNotice messageNotice = (MessageNotice) HuyaMonitorWindow.this.mSelectedMessage;
                WupService.getInstance().muteRoomUser(messageNotice.sContent, duration, messageNotice.lPid, messageNotice.tUserInfo.lUid, messageNotice.lSid, type, 1);
            }
        }
    }

    private JPopupMenu createPopupMenu() {
        JPopupMenu rootPopupMenu = new JPopupMenu();
        rootPopupMenu.add(createMenuAction("禁言30分钟", MuteRoomUserAction.TYPE_MUTE, 60 * 30));
        rootPopupMenu.add(createMenuAction("禁言1天", MuteRoomUserAction.TYPE_MUTE, 60 * 60 * 24));
        rootPopupMenu.add(createMenuAction("禁言3天", MuteRoomUserAction.TYPE_MUTE, 60 * 60 * 24 * 3));
        rootPopupMenu.add(createMenuAction("禁言7天", MuteRoomUserAction.TYPE_MUTE, 60 * 60 * 24 * 7));
        JMenu blackPopupMenu = new JMenu("拉黑");
        rootPopupMenu.add(blackPopupMenu);
        blackPopupMenu.add(createMenuAction("拉黑30分钟", MuteRoomUserAction.TYPE_BLOCK, 60 * 30));
        blackPopupMenu.add(createMenuAction("拉黑1天", MuteRoomUserAction.TYPE_BLOCK, 60 * 60 * 24));
        blackPopupMenu.add(createMenuAction("拉黑3天", MuteRoomUserAction.TYPE_BLOCK, 60 * 60 * 24 * 3));
        blackPopupMenu.add(createMenuAction("拉黑7天", MuteRoomUserAction.TYPE_BLOCK, 60 * 60 * 24 * 7));
        return rootPopupMenu;
    }

    private void initEventBus() {
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        CommonLib.getInstance().init();
    }

    @Subscribe
    public void onPushMessage(MessageNotice messageNotice) {
        notifyMessage(messageNotice);
    }

    @Subscribe
    public void onAuditorRoleChangeNotice(AuditorRoleChangeNotice auditorRoleChangeNotice) {
        notifyMessage(auditorRoleChangeNotice);
    }

    @Subscribe
    public void onAttendeeCountNotice(AttendeeCountNotice attendeeCountNotice) {

    }

    @Subscribe
    public void onSendMessageRsp(SendMessageRsp sendMessageRsp) {

    }

    @Subscribe
    public void onMuteRoomUserRsp(MuteRoomUserRsp muteRoomUserRsp) {
        if (muteRoomUserRsp.iRetCode == 0) {
            HuyaMonitorService.getInstance().showNotification("禁言成功");
        }
    }

    @Subscribe
    public void onSocketLoginFinished(SocketLoginFinished loginFinished) {
        scanLogin.getTemplatePresentation().setEnabled(!loginFinished.loginSuccessful);
    }

    private void notifyMessage(JceStruct jceStruct) {
        ApplicationManager.getApplication().invokeLater(() -> {
            if (defaultListModel.size() > maxCount) {
                defaultListModel.remove(0);
            }
            defaultListModel.addElement(jceStruct);
            if (!mScrollerLocked) {
                barrage_list.ensureIndexIsVisible(defaultListModel.getSize() - 1);
            }
        });
    }

    public void initToolWindow(ToolWindow toolWindow) {
        ContentManager contentManager = toolWindow.getContentManager();
        ContentFactory contentFactory = ContentFactory.SERVICE.getInstance();
        Content content = contentFactory.createContent(null, null, true);
        content.setCloseable(false);
        DefaultActionGroup actionGroup = new DefaultActionGroup();
        actionGroup.add(startMonitor);
        actionGroup.add(scanLogin);
        actionToolbar = ActionManager.getInstance().createActionToolbar("HuyaPreviewViewToolbar", actionGroup, true);
        windowPanel = new PreviewComponent(this);
        content.setComponent(windowPanel);
        windowPanel.setToolbar(actionToolbar.getComponent());
        windowPanel.setContent(this.content);
        contentManager.addContent(content);
        contentManager.setSelectedContent(content);
    }
}
