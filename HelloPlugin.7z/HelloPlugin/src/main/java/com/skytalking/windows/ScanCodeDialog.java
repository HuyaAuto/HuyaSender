package com.skytalking.windows;

import javax.swing.*;

public class ScanCodeDialog {
    public JPanel contentPanel;
}
