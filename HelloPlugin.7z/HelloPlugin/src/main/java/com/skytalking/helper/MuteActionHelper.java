package com.skytalking.helper;

public class MuteActionHelper {

    public static void mute() {

    }
}
