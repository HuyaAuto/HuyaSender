package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

public interface PluginIcons {
    Icon YUE_YUE = IconLoader.getIcon("/icons/yueyue.jpg");
    Icon MONITOR = IconLoader.getIcon("/icons/monitor.png");
    Icon SCAN = IconLoader.getIcon("/icons/scan.png");
    Icon MUTE = IconLoader.getIcon("/icons/mute.png");
    Icon BLACK = IconLoader.getIcon("/icons/black.png");
}
